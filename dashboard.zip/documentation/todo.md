Refactor to de-monolith the core
Redo documentation for architecure.

To display this page, Firefox must send information that will repeat any action (such as a search or order confirmation) that was performed earlier.

additional feature requests: Widget settings I would like to be able to change the name and the icon. Same with the Header icon. 

Allow altering default settings in settings (What widgets load by default) I'd like to remove a widget entirely, but it loads by default and I keep having to change the default Title, and I'd like to be able to choose my own icons, can you give a menu of icons to choose from for both widgets and Title?

pre api helper files: tables, search, cache

