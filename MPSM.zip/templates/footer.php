    </main>
    <footer>
        <p>Version <?= APP_VERSION ?> &copy; <?= date('Y') ?></p>
    </footer>
    <script src="/dashboard/script.js"></script>
</body>
</html>