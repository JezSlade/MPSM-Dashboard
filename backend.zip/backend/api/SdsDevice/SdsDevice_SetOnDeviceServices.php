<?php
// Auto-generated endpoint: /SdsDevice/SetOnDeviceServices [POST]
// Operation ID: SdsDevice/SetOnDeviceServices

require_once __DIR__ . '/../../core/ApiCaller.php';

try {
    $result = ApiCaller::request('POST', '/SdsDevice/SetOnDeviceServices');
    header('Content-Type: application/json');
    echo json_encode($result);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
