<?php
?>
<h1>Dashboard</h1>
<p>Welcome to the dashboard. This is the default module visible to all authenticated users.</p>
