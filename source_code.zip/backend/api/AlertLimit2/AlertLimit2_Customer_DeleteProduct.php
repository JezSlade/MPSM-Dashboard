<?php
// Auto-generated endpoint: /AlertLimit2/Customer/DeleteProduct [DELETE]
// Operation ID: AlertLimit2/Customer/DeleteProduct

require_once __DIR__ . '/../../core/ApiCaller.php';

try {
    $result = ApiCaller::request('DELETE', '/AlertLimit2/Customer/DeleteProduct');
    header('Content-Type: application/json');
    echo json_encode($result);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
