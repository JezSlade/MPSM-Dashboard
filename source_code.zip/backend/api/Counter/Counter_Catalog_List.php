<?php
// Auto-generated endpoint: /Counter/Catalog/List [POST]
// Operation ID: Counter/Catalog/List

require_once __DIR__ . '/../../core/ApiCaller.php';

try {
    $result = ApiCaller::request('POST', '/Counter/Catalog/List');
    header('Content-Type: application/json');
    echo json_encode($result);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
