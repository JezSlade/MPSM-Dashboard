<?php
// widgets/stats_widget.php
?>
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-value">1,254</div>
        <div class="stat-label">Visitors</div>
        <i class="fas fa-users"></i>
    </div>
    <div class="stat-card">
        <div class="stat-value">$7,842</div>
        <div class="stat-label">Revenue</div>
        <i class="fas fa-dollar-sign"></i>
    </div>
    <div class="stat-card">
        <div class="stat-value">64%</div>
        <div class="stat-label">Conversion</div>
        <i class="fas fa-percentage"></i>
    </div>
    <div class="stat-card">
        <div class="stat-value">312</div>
        <div class="stat-label">Orders</div>
        <i class="fas fa-shopping-cart"></i>
    </div>
</div>