<?php
// includes/footer.php
// -------------------------------------------------------------------
// Footer only—no CSS here.
// -------------------------------------------------------------------
?>
<footer class="app-footer">
  &copy; <?= date('Y') ?> Resolutions by Design — All rights reserved.
</footer>
