# ToDo

- Customer table select row -> sets global customer
- slide-out drill-down for card template
- 