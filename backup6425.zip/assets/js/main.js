// /public/mpsm/assets/js/main.js

document.addEventListener('DOMContentLoaded', function() {
  console.log('MPSM Dashboard loaded.');
});
