<?php
// includes/card_base.php
// Wraps every card in the shared glassmorphic container
?>

<div class="card-wrapper">
  <!-- shared controls (theme toggle, debug badge, etc.) could go here -->
<?php
// After this include, each card file echoes its own <div class="card">…</div>
