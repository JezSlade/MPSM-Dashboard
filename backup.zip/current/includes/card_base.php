<?php
// includes/card_base.php — Wraps each card in the glassmorphic container
?>
<div class="card-wrapper p-4 flex justify-center">
  <!-- Card markup (with .card) follows in each card file -->
