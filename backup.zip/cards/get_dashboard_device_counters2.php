<?php declare(strict_types=1);
// /api/get_dashboard_device_counters2.php

$path           = 'Dashboard/GetDeviceCounters2';
$requiredFields = [];
$useCache       = true;

require __DIR__ . '/../includes/api_bootstrap.php';
