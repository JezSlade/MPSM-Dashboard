<?php declare(strict_types=1);
// /api/get_device_overview.php

$path           = 'Device/GetDeviceOverview';
$requiredFields = ['id'];
$useCache       = true;

require __DIR__ . '/../includes/api_bootstrap.php';
