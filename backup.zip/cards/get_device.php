<?php declare(strict_types=1);
// /api/get_device.php

$path           = 'Device/GetDevice';
$requiredFields = ['id'];
$useCache       = true;

require __DIR__ . '/../includes/api_bootstrap.php';
