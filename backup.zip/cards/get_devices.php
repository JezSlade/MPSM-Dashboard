<?php declare(strict_types=1);
// /api/get_devices.php

$path           = 'Device/GetDevices';
$requiredFields = [];
$useCache       = true;

require __DIR__ . '/../includes/api_bootstrap.php';
