<?php declare(strict_types=1);
// /api/get_dashboard_device_actions_dashboard.php

$path           = 'Dashboard/GetDeviceActionsDashboard';
$requiredFields = [];
$useCache       = true;

require __DIR__ . '/../includes/api_bootstrap.php';
