<?php declare(strict_types=1);
// /api/get_customers.php

$path           = 'Customer/GetCustomers';
$requiredFields = [];
$useCache       = true;

require __DIR__ . '/../includes/api_bootstrap.php';
