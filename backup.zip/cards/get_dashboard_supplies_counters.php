<?php declare(strict_types=1);
// /api/get_dashboard_supplies_counters.php

$path           = 'Dashboard/GetSuppliesCounters';
$requiredFields = [];
$useCache       = true;

require __DIR__ . '/../includes/api_bootstrap.php';
