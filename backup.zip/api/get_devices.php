<?php declare(strict_types=1);
// /api/get_devices.php

$method   = 'POST';
$path     = 'Device/GetDevices';
$useCache = true;

require __DIR__ . '/../includes/api_bootstrap.php';
