<?php declare(strict_types=1);
// /api/get_customers.php

$method   = 'POST';
$path     = 'Customer/GetCustomers';
$useCache = true;

require __DIR__ . '/../includes/api_bootstrap.php';
