# ToDo

- Card Pagination default setting adjustable from settings.
- Standardize Tables
- 