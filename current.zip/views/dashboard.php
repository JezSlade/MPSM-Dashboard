<!DOCTYPE html><html lang="en"><head>
  <meta charset="UTF-8"><title>Dashboard</title>
</head><body>
<?php include __DIR__.'/../includes/header.php';?>
<?php include __DIR__.'/../includes/navigation.php';?>
<main><?php include __DIR__.'/../cards/CustomersCard.php';?></main>
<?php include __DIR__.'/../includes/footer.php';?>
</body></html>
