<?php
// views/detail_modal.php
?>
<div id="detail-modal" class="modal">
  <div class="modal-content"><span class="close">&times;</span><div id="detail-body"></div></div>
</div>
