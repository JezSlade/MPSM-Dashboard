# 📘 Counter HTTP Helper Usage Guide (PHP)

These helpers support Counter-related endpoints for all HTTP methods.
