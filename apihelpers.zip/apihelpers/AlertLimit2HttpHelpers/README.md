# 📘 AlertLimit2 HTTP Helper Usage Guide (PHP)

These helpers support AlertLimit2-related endpoints for all HTTP methods.
